package main;

import java.util.concurrent.locks.StampedLock;

/**
 * Runnable object used to randomly generate {@link ClientRequest} objects.
 * @author alexis
 *
 */

public class ClientRequestSimulator implements Runnable {	
	
	// ATTRIBUTES
	private Asset asset;
	private static double REQUESTSFREQUENCY = 1e-3;
	
	
	// CONSTRUCTOR
	/**
	 * Initializes the object given an {@link Asset}.
	 */
	public ClientRequestSimulator(Asset asset) {this.asset = asset;}
	
	
	// MAIN METHODS
	/**
	 * Requests are assumed to arrive randomly, following an Exponential distribution.
	 * The simulation runs during 1 minute.
	 */
	public void run() {
		long t = System.currentTimeMillis();
		long end = t+60000;
		RandomHelper rh = new RandomHelper();
		while(System.currentTimeMillis() < end) {
			
			try {
				Thread.sleep((long) rh.nextExponential(REQUESTSFREQUENCY));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			ClientRequest clientRequest = new ClientRequest(asset);
			StampedLock lock = new StampedLock();
	    	long stamp = lock.writeLock();
	    	try {clientRequest.answerClient();}
	    	finally {lock.unlock(stamp);}

		}
	}
	
}
