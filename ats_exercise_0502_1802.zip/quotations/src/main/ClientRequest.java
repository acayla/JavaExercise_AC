package main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Client request.
 * @author alexis
 *
 */

public class ClientRequest {
	
	// ATTRIBUTES
	private Asset asset;
	private String direction;
	private int quantity;
	
	
	// CONSTRUCTOR
	/**
	 * Builds a specified {@link ClientRequest}.
	 * @param asset
	 * 		{@link Asset} object.
	 * @param direction
	 * 		String representing the direction of the request (i.e. "Ask" or "Bid").
	 * @param quantity
	 * 		Notional.
	 */
	public ClientRequest(Asset asset, String direction, int quantity) {
		this.asset = asset;
		this.direction = direction;
		this.quantity = quantity;
	};
	
	
	/**
	 * Builds a random {@link ClientRequest}.
	 * @param asset
	 */
	public ClientRequest(Asset asset) {
		this.asset = asset;
		String direction;
		if (Math.random() > 0.5) direction = "Bid";
		else direction = "Ask";
		int quantity = (int) ((int) 10000 * Math.random());
		this.direction = direction;
		this.quantity = quantity;
	}
	
	
	// GET
	/**
	 * 
	 * @return Asset.
	 */
	public Asset getAsset() {return asset;}
	
	
	/**
	 * 
	 * @return Direction (i.e. "Ask" or "Bid").
	 */
	public String getDirection() {return direction;}
	
	
	/**
	 * 
	 * @return Notional.
	 */
	public int getQuantity() {return quantity;}
	
	
	// SET
	/**
	 * 
	 * @param direction
	 * 		New direction.
	 */
	public void setDirection(String direction) {this.direction = direction;}
	
	
	/**
	 * 
	 * @param quantity
	 * 		New quantity.
	 */
	public void setQuantity(int quantity) {this.quantity = quantity;}
		
		
	// PRINTER
	/**
	 * Prints the request and its result.
	 */
	public void answerClient() {
		double clientPrice;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
		LocalDateTime currentTime = LocalDateTime.now();
		System.out.println(formatter.format(currentTime));
		if (this.direction == "Bid") clientPrice = asset.getBidPrice(quantity);
		else clientPrice = asset.getAskPrice(quantity);
		
		if (this.asset.getClass() != ZCBond.class) {
			clientPrice *= 100;
		}
		
		String strClientPrice = String.format(Locale.US, "%.5f", clientPrice) + "%";
		
		System.out.println("-- CLIENT REQUEST --");
		System.out.println("Direction: " + this.direction);
		System.out.println("Quantity: " + this.quantity);
		System.out.println("Price: " + strClientPrice);
	}
	
}
