package main;

import java.util.Random;

/**
 * Extends Random class to provide additional distributions.
 * @author alexis
 *
 */
public class RandomHelper extends Random {
	
	private static final long serialVersionUID = 1L;

	public RandomHelper() {
		super();
	}
	
	/**
	 * Returns a random variable following an Exponential distribution with parameter lambda.
	 * @param lambda
	 * 		Intensity parameter.
	 * @return
	 * 		Exponentially distributed random variable.
	 */
	public double nextExponential(double lambda) {
		return  Math.log(1-super.nextDouble())/(-lambda);
	}
	
}
