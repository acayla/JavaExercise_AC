package main;

/**
 * Market order. This class is just a wrapper for the abstract class {@link Order}.
 * @author alexis
 *
 */

public class MarketOrder extends Order {

	// CONSTRUCTOR
	/**
	 * Market order constructor.
	 * @param direction
	 * 		Direction of the order (i.e. "Ask" or "Bid").
	 * @param orderSize
	 * 		Notional.
	 */
	public MarketOrder(String direction, Integer orderSize) {
		super(direction, orderSize);
	}
	
	
	// PRINTER
	/**
	 * Prints the order as e.g. [Bid, 1000].
	 */
	public void print() {
		System.out.println("[" + this.direction + ", " + this.orderSize +"]");
	}

}
