package main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * We assume Swaps do not have an order book, and must be rebuilt from a bond and a spread.
 * @author alexis
 *
 */

public class Swap extends Asset {
	
	// ATTRIBUTES
	ZCBond bond;
	AssetSwapSpread bondSpread;
	LocalDate valDate;
	
	
	// CONSTRUCTOR
	/**
	 * @param assetName
	 * 		Name of the asset.
	 * @param bond
	 * 		Bond used to reconstruct the swap rate.
	 * @param bondSpread
	 * 		Asset swap spread used to reconstruct the swap rate.
	 * @param strValDate
	 * 		Valuation date (String, yyyymmdd formatted) passed to compute the yield to maturity of
	 * the underlying bond.
	 */
	public Swap(String assetName, ZCBond bond, AssetSwapSpread bondSpread, String strValDate) {
		super(assetName);
		this.bond = bond;
		this.bondSpread = bondSpread;
		this.valDate = LocalDate.parse(strValDate, DateTimeFormatter.ISO_LOCAL_DATE);
	}
	
	
	// MAIN METHODS
	/**
	 * Simulates the bond and the spread dynamics in two parallel threads.
	 */
	public void run() {
		Thread thread1 = new Thread() {
		    public void run() {
		        bond.run();
		    }
		};

		Thread thread2 = new Thread() {
		    public void run() {
		    	bondSpread.run();
		    }
		};

		// Start the threads.
		thread1.start();
		thread2.start();

		// Wait for them both to finish
		try {
			thread1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		try {
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Computes the bid price of the swap for a notional, given the current state of the order book.
	 * @param quantity
	 * 		Notional of the swap.
	 * @return
	 * 		Synthetic swap par rate given the yield to maturity of the underlying bond and the asset swap spread.
	 */
	@Override
	public double getBidPrice(int quantity) {
		double bondAskPrice = this.bond.getAskPrice(quantity);
		// Ask for the bond <=> Bid for the yield to maturity
		double bondBidYieldToMaturity = this.bond.getYieldToMaturity(this.valDate, bondAskPrice);
		double spreadBid = this.bondSpread.getBidPrice(quantity);
		return bondBidYieldToMaturity + spreadBid / 1e4;
	}

	/**
	 * Computes the ask price of the swap for a notional, given the current state of the order book.
	 * @param quantity
	 * 		Notional of the swap.
	 * @return
	 * 		Synthetic swap par rate given the yield to maturity of the underlying bond and the asset swap spread.
	 */
	@Override
	public double getAskPrice(int quantity) {
		double bondBidPrice = this.bond.getBidPrice(quantity);
		// Bid for the bond <=> Ask for the yield to maturity
		double bondAskYieldToMaturity = this.bond.getYieldToMaturity(this.valDate, bondBidPrice);
		double spreadAsk = this.bondSpread.getAskPrice(quantity);
		return bondAskYieldToMaturity + spreadAsk / 1e4;
	}
	
}
