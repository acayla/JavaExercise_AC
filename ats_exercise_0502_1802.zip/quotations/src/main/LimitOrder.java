package main;

import java.util.Locale;

/**
 * Limit orders.
 * @author alexis
 *
 */

public class LimitOrder extends Order {

	// ATTRIBUTES
	private double quote;
	
	
	// CONSTRUCTOR
	/**
	 * 
	 * @param direction
	 * 		Direction of the limit order (i.e. "Ask" or "Bid").
	 * @param orderSize
	 * 		Notional.
	 * @param quote
	 * 		Limit price.
	 */
	public LimitOrder(String direction, Integer orderSize, double quote) {
		super(direction, orderSize);
		this.quote = quote;
	}
	
	
	// GET
	/**
	 * @return
	 * 		Limit price.
	 */
	public double getQuote() {return quote;};
	
	
	// SET
	/**
	 * 
	 * @param quote
	 * 		Limit price.
	 */
	public void setQuote(double quote) {this.quote = quote;};
	
	
	// PRINTER
	/**
	 * Formats a double to be printed nicely.
	 * @param d
	 * 		double object we want to format before printing.
	 * @return
	 */
	private static String niceFormat(double d)
	{
		if(d % 1 == 0) return String.format(Locale.US, "%.0f", d);
		else return String.format(Locale.US, "%.3f", d);
	}

	
	/**
	 * Actual printer.
	 */
	public void print() {
		String strQuote = LimitOrder.niceFormat(this.quote);;
		System.out.println("[" + this.direction + ", " + this.orderSize + ", " + strQuote+ "]");
	}
	
	
	// MAIN METHODS
	/**
	 * Rounds a quote to the closest tickSize.
	 * @param tickSize
	 * 		Tick size we want to round to.
	 */
	public void roundQuote(double tickSize) {
		quote = tickSize * (int)(quote / tickSize + 0.5);
	}
	
}
