package main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.StampedLock;

/**
 * OrderBook class.
 * @author alexis
 *
 */

public class OrderBook implements Runnable {
	
	// ATTRIBUTES
	private Vector<LimitOrder> vecBidOrders = new Vector<LimitOrder>();
	private Vector<LimitOrder> vecAskOrders = new Vector<LimitOrder>();
	private double tickSize;
	private String orderBookName = "OrderBook";
	
	
	// CLASS CONSTANTS. FEEL FREE TO CHANGE FOR SIMULATIONS.
	/**
	 * 2.576 so that 99% of the new orders have a quote in the existing OrderBook.
	 * 3.090 so that 99,8% of the new orders have a quote in the existing OrderBook.
	 */
	//private static double QUANTILE = 2.576;
	private static double QUANTILE = 3.090;
	private static double P_LIMIT_ORDER = 0.6;
	private static double P_MARKET_ORDER = 0.3;
	private static double P_CANCEL_ORDER = 1 - P_LIMIT_ORDER - P_MARKET_ORDER;
	/**
	 * Average number of orders per millisecond.
	 */
	private static double ORDERSFREQUENCY = 1e-3;
	
	
	// CONSTRUCTORS
	/**
	 * 
	 * @param vecOrders
	 * 		Vector of LimitOrders.
	 * @param tickSize
	 * 		Tick size.
	 * @param orderBookName
	 * 		Name of the order book.
	 */
	public OrderBook(Vector<LimitOrder> vecOrders, double tickSize, String orderBookName) {
		this.tickSize = tickSize;
		this.orderBookName = orderBookName;
		Iterator<LimitOrder> itr = vecOrders.iterator();
		while (itr.hasNext()) {
			try {this.insertOrder(itr.next());}
			catch (Exception e) {e.printStackTrace();}
		}
	};
	
	
	/**
	 * 
	 * @param vecOrders
	 * 		Vector of limit orders.
	 * @param tickSize
	 * 		Tick size.
	 */
	public OrderBook(Vector<LimitOrder> vecOrders, double tickSize) {
		this.tickSize = tickSize;
		Iterator<LimitOrder> itr = vecOrders.iterator();
		while (itr.hasNext()) {
			try {this.insertOrder(itr.next());}
			catch (Exception e) {e.printStackTrace();}
		}
	};
	
	
	/**
	 * 
	 * @param minAsk
	 * 		Minimal quote we want to include in the order book.
	 * @param maxBid
	 * 		Maximal quote we want to include in the order book.
	 * @param tickSize
	 * 		Tick size.
	 * @param expectedQuantity
	 * 		Order of magnitude of the notionals.
	 * @param orderBookName
	 * 		Name of the order book.
	 */
	public OrderBook(double minAsk, double maxBid, double tickSize, int expectedQuantity, String orderBookName) {
		this.tickSize = tickSize;
		this.orderBookName = orderBookName;
		this.randomInitialization(minAsk, maxBid, expectedQuantity);
	};
	
	
	/**
	 * 
	 * @param minAsk
	 * 		Minimal quote we want to include in the order book.
	 * @param maxBid
	 * 		Maximal quote we want to include in the order book.
	 * @param tickSize
	 * 		Tick size.
	 * @param expectedQuantity
	 * 		Order of magnitude of the notionals.
	 */
	public OrderBook(double minAsk, double maxBid, double tickSize, int expectedQuantity) {
		this.tickSize = tickSize;
		this.randomInitialization(minAsk, maxBid, expectedQuantity);
	};
	
	
	
	// GET
	public Vector<LimitOrder> getBidOrders() {return vecBidOrders;}
	public Vector<LimitOrder> getAskOrders() {return vecAskOrders;}
	public double getTickSize() {return tickSize;}
	public double getMinBid() {return this.vecBidOrders.lastElement().getQuote();}
	public double getMaxBid() {return this.vecBidOrders.firstElement().getQuote();}
	public double getMinAsk() {return this.vecAskOrders.lastElement().getQuote();}
	public double getMaxAsk() {return this.vecAskOrders.firstElement().getQuote();}
	
	/**
	 * 
	 * @return Largest notional found across all the limit orders in the book.
	 */
	public double getMaxOrderSize() {
		
		Iterator<LimitOrder> itr;
		LimitOrder currentOrder;
		int maxOrderSize = -1;
		
		itr = this.vecAskOrders.iterator();
        while (itr.hasNext()) {
          currentOrder = itr.next();
          if (maxOrderSize < 0 || currentOrder.getOrderSize() > maxOrderSize) {
        	  maxOrderSize = currentOrder.getOrderSize();
          }
        }
        
        itr = this.vecBidOrders.iterator();
        while (itr.hasNext()) {
            currentOrder = itr.next();
            if (maxOrderSize < 0 || currentOrder.getOrderSize() > maxOrderSize) {
          	  maxOrderSize = currentOrder.getOrderSize();
            }
          }
    
        return maxOrderSize;
	}
	

	
	// PRINTER
	/**
	 * Prints the order book in the console.
	 */
	public void print() {
		System.out.println();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
		LocalDateTime currentTime = LocalDateTime.now();
		System.out.println("- " + this.orderBookName + " -" );
		System.out.println(formatter.format(currentTime));
		Iterator<LimitOrder> itr = this.vecAskOrders.iterator();
        while (itr.hasNext()) {
          itr.next().print();
        }
        itr = this.vecBidOrders.iterator();
        System.out.println("-- MID --");
        while (itr.hasNext()) {
          itr.next().print();
        }
        System.out.println();
	}
	
	
	
	// PRIVATE HELPERS
	/**
	 * Removes all the orders having a 0 notional.
	 */
	private void cleanOrderBook() {
		
		Iterator<LimitOrder> itr = this.vecAskOrders.iterator();
		while (itr.hasNext()) {
          int orderSize = itr.next().getOrderSize();
          if (orderSize == 0) itr.remove();
	    }
		
		itr = this.vecBidOrders.iterator();
		while (itr.hasNext()) {
          int orderSize = itr.next().getOrderSize();
          if (orderSize == 0) itr.remove();
	    }
	}
	
	
	
	// MAIN METHODS
	/**
	 * Randomly initializes the order book. Quantities are random and should be not too far from
	 * expectedQuantity.
	 * @param minBid
	 * 		Lowest value in the Bid section of the order book.
	 * @param maxAsk
	 * 		Largest value in the Ask section of the order book.
	 * @param expectedQuantity
	 * 		Order of magnitude of the quantities.
	 */
	public void randomInitialization(double minBid, double maxAsk, int expectedQuantity){
		
		Random r = new Random();
		double midPrice = (minBid + maxAsk) / 2;
		
		// Randomly initialize the order book with bids
		for (double askQuote = maxAsk; askQuote > midPrice; askQuote -= this.tickSize) {
			double randomQuantity = expectedQuantity * 0.1 * r.nextGaussian();
			int quantity = Math.max(0, expectedQuantity + (int) randomQuantity);
			try {
				this.insertOrder(new LimitOrder("Ask", quantity, askQuote));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// Randomly initialize the order book with asks
		for (double bidQuote = minBid; bidQuote < midPrice; bidQuote += this.tickSize) {
			double randomQuantity = expectedQuantity * r.nextGaussian();
			int quantity = Math.max(0, expectedQuantity + (int) randomQuantity);
			try {
				this.insertOrder(new LimitOrder("Bid", quantity, bidQuote));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		this.cleanOrderBook();
		
	}
	
	
	/**
	 * Carefully inserts a new {@link LimitOrder} in the book.
	 * Preserves the ordered Bid and Ask vectors.
	 * Preserves the unicity of the quotes.
	 * @param newOrder
	 * 		{@link LimitOrder} object to add to the book.
	 * @throws Exception
	 */
	public void insertOrder(Order newOrder) throws Exception {	
		if (newOrder.getClass() == LimitOrder.class) {
			this.insertOrder((LimitOrder) newOrder);
		}
		else if (newOrder.getClass() == MarketOrder.class) {
			this.insertOrder((MarketOrder) newOrder);
		}
		else if (newOrder.getClass() == CancelOrder.class) {
			this.insertOrder((CancelOrder) newOrder);
		}
		else {throw new Exception("Unknown order type: "+newOrder.getClass().getName()+".");}
	}
		
	
	/**
	 * 
	 * @param newOrder
	 * 		{@link LimitOrder} to be inserted.
	 * @throws Exception
	 * 		Exception thrown in case of failure.
	 */
	public void insertOrder(LimitOrder newOrder) throws Exception {	
		
		Iterator<LimitOrder> itr;
		Integer position = 0;
		newOrder.roundQuote(tickSize);
		double newQuote = newOrder.getQuote();
		int newOrderSize = newOrder.getOrderSize();
		String direction = newOrder.getDirection();
		boolean insertedOrder = false;
        
		if (direction == "Bid") {
			if (this.vecBidOrders.isEmpty()) {
				this.vecBidOrders.add(newOrder);
				insertedOrder = true;
			}
			else if (!this.vecAskOrders.isEmpty() && newOrder.getQuote() >= this.getMinAsk()) {
				MarketOrder marketOrder = new MarketOrder(newOrder.direction, newOrder.getOrderSize());
				this.insertOrder(marketOrder);
				insertedOrder = true;
			}
			itr = this.vecBidOrders.iterator();
		}
		
		else if (direction == "Ask") {
			if (this.vecAskOrders.isEmpty()) {
				this.vecAskOrders.add(newOrder);
				insertedOrder = true;
			}
			else if (!this.vecBidOrders.isEmpty() && newOrder.getQuote() <= this.getMaxBid()) {
				MarketOrder marketOrder = new MarketOrder(newOrder.direction, newOrder.getOrderSize());
				this.insertOrder(marketOrder);
				insertedOrder = true;
			}
			itr = this.vecAskOrders.iterator();
		}
		
		else{throw new Exception("Unknown order's direction: "+direction+".");}
		
		while (itr.hasNext() && !insertedOrder) {
			
			position++;
			LimitOrder currentOrder = itr.next();
			double currentQuote = currentOrder.getQuote();
			
			if (newQuote > currentQuote) {
				if (direction == "Bid") this.vecBidOrders.add(position-1, newOrder);
				else this.vecAskOrders.add(position-1, newOrder);
				insertedOrder = true;
			}
			
			else if (newQuote == currentQuote) {
				currentOrder.increaseOrderSize(newOrderSize);
				insertedOrder = true;
			}
			
			else if (!itr.hasNext()) {
				if (direction == "Bid") this.vecBidOrders.add(newOrder);
				else this.vecAskOrders.add(newOrder);
				insertedOrder = true;
			}
		};
	};
	
	
	/**
	 * Executes a {@link MarketOrder} by removing the relevant(s) {@link LimitOrder} from the book.
	 * @param newOrder
	 * 		{@link MarketOrder} object to execute.
	 * @throws Exception
	 */
	public void insertOrder(MarketOrder newOrder) throws Exception {
		
		Integer position = 0;
		int newOrderSize = newOrder.getOrderSize();
		String direction = newOrder.getDirection();
		
		if (direction == "Bid") {
			position = this.vecAskOrders.size() - 1;
			while (newOrderSize > 0 && position >= 0) {
				LimitOrder currentOrder = this.vecAskOrders.get(position);
				int currentQuantity = currentOrder.getOrderSize();
				if (currentQuantity <= newOrderSize) {
					this.vecAskOrders.get(position).setOrderSize(0);
					newOrderSize -= currentQuantity;
					position--;
				}
				else {
					this.vecAskOrders.get(position).increaseOrderSize(-newOrderSize);
					newOrderSize = 0;
				}
			}
		}
		
		else if (direction == "Ask") {
			position = 0;
			while (newOrderSize > 0 && position < this.vecBidOrders.size()) {
				LimitOrder currentOrder = this.vecBidOrders.get(position);
				int currentQuantity = currentOrder.getOrderSize();
				if (currentQuantity <= newOrderSize) {
					this.vecBidOrders.get(position).setOrderSize(0);
					newOrderSize -= currentQuantity;
					position++;
				}
				else {
					this.vecBidOrders.get(position).increaseOrderSize(-newOrderSize);
					newOrderSize = 0;
				}
			}
		}
		
		else{throw new Exception("Unknown order's direction: "+direction+".");}
		
		cleanOrderBook();
		
	}
	
	
	/**
	 * Executes a {@link CancelOrder} by removing the relevant(s) {@link LimitOrder} from the book.
	 * @param newOrder
	 * 		{@link CancelOrder} object to execute.
	 * @throws Exception
	 */
	public void insertOrder(CancelOrder newOrder) throws Exception {
		
		Vector<LimitOrder> vecToModify;
		boolean executedOrder = false;
		int orderSize = newOrder.getOrderSize();
		String direction = newOrder.getDirection();
		
		if (direction == "Bid") vecToModify = this.vecBidOrders;
		else vecToModify = this.vecAskOrders;
		Iterator<LimitOrder> it = vecToModify.iterator();
		
		while (it.hasNext() && !executedOrder) {
			LimitOrder currentOrder = it.next();
			if (currentOrder.getQuote() == newOrder.getQuote()) 
			{
				currentOrder.increaseOrderSize(-Math.min(currentOrder.orderSize, orderSize));
				executedOrder = true;
			}
		}
		
		cleanOrderBook();
		
	}
	
	/**
	 * 
	 * @return
	 * 		Mid price of the order book.
	 */
	public double getMidPrice() {
		return (this.getMaxBid() + this.getMinAsk()) / 2.0 ;
	}
	
	
	/**
	 * Rounds a value to the closest precision.
	 * @param value
	 * 		Value to round.
	 * @return
	 * 		Rounder value.
	 */
	private double round(double value) {
	    return tickSize * (int)(value / tickSize + 0.5) ;
	}
	
	
	/**
	 * Simulates the order book.
	 */
	public void run() {
		
		RandomHelper rh = new RandomHelper();
		int nbSecondsRun = 60;
		String direction;
		int size;
		double quote;

		long t= System.currentTimeMillis();
		long end = t+nbSecondsRun*1000;
		while(System.currentTimeMillis() < end) {
	
			/* We wait a random time before the arrival of a new order.
			 * This random time is assume to be Exponentially distributed with,
			 * on average, ORDERSFREQUENCY new order per millisecond.
			 */
			try {
				Thread.sleep((long) rh.nextExponential(ORDERSFREQUENCY));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			/*
			 * We randomly pick a type of order:
			 * 	- LimitOrder with p = 0.7
			 * 	- MarketOrder with p = 0.2
			 *  - CancelOrder with p = 0.1
			 * 
			 * The order's size is assumed to be uniformly distributed between zero and the current
			 * largest order size, divided by 10.
			 * Indeed, each row of the order book is an aggregated view, implying that individual
			 * orders are expected to be smaller. We assume they should be by a ~10 factor.
			 * Limit: No large orders arriving in this model. Corrected below.
			 * 
			 * For both LimitOrder and CancelOrder, we have to randomly set a quote.
			 * The order's quote follows a Gaussian distribution around the mid-price,
			 * with p = 0.99 of being in the current order book.
			 * Then, we round it to the closest tickSize. 
			 * We set the direction depending on which side of the order book the quote is in.
			 * 
			 */
			
			// ORDER TYPE
			double orderTypeSelector = Math.random();
			
			// SIZE
			size = (int) (getMaxOrderSize() * Math.random() / 10);
			
			// QUOTE
			double midPrice = getMidPrice();
			double minPrice = getMinBid();
			double maxPrice = getMaxAsk();
			double sigma = (maxPrice - minPrice) / (2*QUANTILE);
			quote = this.round(midPrice + sigma * rh.nextGaussian());
			
			// DIRECTION
			if (quote > midPrice) direction = "Ask";
			else direction = "Bid";
			
	    	Order order;
	    	if (orderTypeSelector < P_LIMIT_ORDER) {
	    		order = new LimitOrder(direction, size, quote);
	    	} else if (orderTypeSelector < P_LIMIT_ORDER + P_CANCEL_ORDER) {
	    		order = new CancelOrder(direction, size, quote);
	    	} else {
		    	/*
				 * From time to times (e.g. 5% of the market orders), a big market order comes to
				 * consume liquidity.
				 */
	    		if (rh.nextDouble() < 0.05) {size *= 15;}
	    		order = new MarketOrder(direction, size);
			}
	    	
	    	try {insertOrder(order);}
	    	catch (Exception e1) {e1.printStackTrace();}
	    	
	    	// We lock the access to the console to ensure the OrderBook is readable.
	    	StampedLock lock = new StampedLock();
	    	long stamp = lock.writeLock();
	    	try {print();}
	    	finally {lock.unlock(stamp);}

		}
		
	}

}
