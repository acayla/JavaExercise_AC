package main;

/**
 * Abstract class from which all the order object will derive.
 * @author alexis
 *
 */

abstract public class Order {
	
	// ATTRIBUTES
	protected String direction;
	protected Integer orderSize;
	
	
	// CONSTRUCTOR
	/**
	 * 
	 * @param direction
	 * 		Direction of the order (i.e. "Ask" or "Bid").
	 * @param orderSize
	 * 		Notional.
	 */
	public Order(String direction, Integer orderSize) {
		this.direction = direction;
		this.orderSize = orderSize;
	};
	
	
	// GET
	/**
	 * 
	 * @return Direction of the order (i.e. "Ask" or "Bid".)
	 */
	public String getDirection() {return this.direction;};
	
	
	/**
	 * 
	 * @return Notional of the order.
	 */
	public Integer getOrderSize() {return this.orderSize;};
	
	
	// SET
	/**
	 * Changes the notional.
	 * @param orderSize
	 * 		New notional.
	 */
	public void setOrderSize(int orderSize) {this.orderSize = orderSize;}
	
	
	// PRINTER
	/**
	 * Abstract method. Each Order should be printable.
	 */
	public abstract void print();
	
	
	// MAIN
	/**
	 * Increases the size of an existing order. Useful when managing an {@link OrderBook}.
	 * @param orderSize
	 * 		Additional nominal.
	 */
	public void increaseOrderSize(int orderSize) {this.orderSize += orderSize;};
	
}
