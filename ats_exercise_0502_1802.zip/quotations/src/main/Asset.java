package main;

/**
 * Abstract parent class for all the assets. All the {@link Asset} objects can be run.
 * @author alexis
 *
 */

abstract public class Asset implements Runnable {
	
	// ATTRIBUTES
	private String assetName;
	
	
	// CONSTRUCTOR
	/**
	 * Constructor to be called in children classes.
	 * @param assetName
	 * 		Name of the asset.
	 */
	public Asset(String assetName) {this.assetName = assetName;};
	
	
	
	// GET
	/**
	 * Returns the name of the asset.
	 * @return
	 * 		Name of the asset.
	 */
	public String getAssetName(){return assetName;};
	
	
	/**
	 * Abstract method used to provide clients with the price of a bid order, for a given notional.
	 * @param quantity
	 * 		Notional to be treated.
	 * @return
	 * 		Price.
	 */
	public abstract double getBidPrice(int quantity);
	
	
	/**
	 * Abstract method used to provide clients with the price of an ask order, for a given notional.
	 * @param quantity
	 * 		Notional to be treated.
	 * @return
	 * 		Price.
	 */
	public abstract double getAskPrice(int quantity);

	
	// SET
	/**
	 * Modifies the name of the asset.
	 * @param assetName
	 * 		New asset's name.
	 */
	public void setAssetName(String assetName){this.assetName = assetName;};
	
	
	// MAIN
	/**
	 * In our architecture, every Asset object can be run.
	 * Either an Asset is an {@link ExchangedAsset} and thus embeds an order book that can be simulated,
	 * or it contains one or several {@link ExchangedAsset} that will be used to synthesize prices.
	 */
	abstract public void run();
	
}
