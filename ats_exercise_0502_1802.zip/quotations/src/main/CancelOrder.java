package main;

/**
 * Cancel order.
 * @author alexis
 *
 */

public class CancelOrder extends Order {

	private double quote;
	
	// CONSTRUCTOR
	/**
	 * Cancel order constructor.
	 * @param direction
	 * 		Direction of the order (i.e. "Ask" or "Bid").
	 * @param orderSize
	 * 		Notional.
	 * @param quote
	 * 		Quote.
	 */
	public CancelOrder(String direction, Integer orderSize, double quote) {
		super(direction, orderSize);
		this.quote = quote;
	}
	
	// GET
	/**
	 * 
	 * @return Cancel order's quote.
	 */
	public double getQuote() {return quote;}
	
	// PRINTER
	/**
	 * Prints the order as e.g. [Bid, 1000].
	 */
	public void print() {
		System.out.println("[" + this.direction + ", " + this.orderSize +"]");
	}

}
