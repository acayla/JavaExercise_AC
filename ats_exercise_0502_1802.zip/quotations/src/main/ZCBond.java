package main;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Simplified representation of a Zero Coupon Bond.
 * For the sake of simplicity, we do not take into account the market conventions.
 * @author alexis
 *
 */

public class ZCBond extends ExchangedAsset {
	
	// ATTRIBUTES
	LocalDate endDate;
	double faceValue;
	
	
	
	// CONSTRUCTOR
	/**
	 * 
	 * @param bondName
	 * 		Name of the bond (e.g. Bloomberg ticker).
	 * @param strEndDate
	 * 		End date of the bond. String formatted as yyyymmdd.
	 * @param faceValue
	 * 		Face value of the bond.
	 * @param orderBook
	 * 		Pre-initialized order book. @see OrderBook.
	 */
	public ZCBond(String bondName, String strEndDate, double faceValue, OrderBook orderBook) {
		super(bondName, orderBook);
		endDate = LocalDate.parse(strEndDate, DateTimeFormatter.ISO_LOCAL_DATE);
		this.faceValue = faceValue;
	}
	
	/**
	 * 
	 * @param bondName
	 * 		Name of the bond (e.g. Bloomberg ticker).
	 * @param strEndDate
	 * 		End date of the bond. String formatted as yyyymmdd.
	 * @param faceValue
	 * 		Face value of the bond.
	 * @param midPrice
	 * 		Mid price of the bond.
	 * @param tickSize
	 * 		Tick size of the corresponding {@link OrderBook}.
	 */
	public ZCBond(String bondName, String strEndDate, double faceValue, double midPrice, double tickSize) {
		super(bondName, midPrice, tickSize);
		endDate = LocalDate.parse(strEndDate, DateTimeFormatter.ISO_LOCAL_DATE);
		this.faceValue = faceValue;
	}
	
	
	
	// GET
	/**
	 * 
	 * @return Maturity date of the bond.
	 */
	public LocalDate getEndDate() {return endDate;};
	/**
	 * 
	 * @return Face value of the bond.
	 */
	public double getFaceValue() {return faceValue;};
	
	
	
	// SET
	/**
	 * 
	 * @param strEndDate
	 * 		New maturity date of the bond.
	 */
	public void setEndDate(String strEndDate) {
		this.endDate = LocalDate.parse(strEndDate, DateTimeFormatter.ISO_LOCAL_DATE);
	};
		
	
	// MAIN	
	/**
	 * Computes the time to maturity assuming ACT/365 convention.
	 * @param valDate
	 * 		Valuation date.
	 * @return
	 * 		Time to maturity (year fraction).
	 */
	public double getTimeToMaturity(LocalDate valDate) {
		Duration duration = Duration.between(valDate.atStartOfDay(), endDate.atStartOfDay());
		return duration.toDays() / 365.0;
	}
	
	/**
	 * Computes the time to maturity assuming ACT/365 convention.
	 * @param strValDate
	 * 		Valuation date as String (yyyymmdd).
	 * @return
	 * 		Time to maturity (year fraction).
	 */
	public double getTimeToMaturity(String strValDate) {
		return getTimeToMaturity(LocalDate.parse(strValDate, DateTimeFormatter.ISO_LOCAL_DATE));
	}
	
	
	/**
	 * Computes the yield to maturity on valuation date, given a market price.
	 * @param valDate
	 * 		Valuation date.
	 * @param marketPrice
	 * 		Market price.
	 * @return
	 * 		Yield to maturity.
	 */
	public double getYieldToMaturity(LocalDate valDate, double marketPrice) {
		double timeToMaturity = this.getTimeToMaturity(valDate);
		double discountFactor = marketPrice / faceValue;
		double yieldToMaturity = -Math.log(discountFactor) / timeToMaturity;
		return yieldToMaturity;
	}
	
	/**
	 * Computes the yield to maturity on valuation date, given a market price.
	 * @param strValDate
	 * 		Valuation date as String (yyyymmdd).
	 * @param marketPrice
	 * 		Market price.
	 * @return
	 * 		Yield to maturity.
	 */
	public double getYieldToMaturity(String strValDate, double marketPrice) {
		return getYieldToMaturity(LocalDate.parse(strValDate, DateTimeFormatter.ISO_LOCAL_DATE), marketPrice);
	}
	
}
