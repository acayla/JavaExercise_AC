package main;

/**
 * Asset swap spreads instruments.
 * For now, this is just a wrapper for {@link ExchangedAsset}.
 * Useful in case we want to enhance the asset swap spreads without modifying the parent class.
 * @author alexis
 *
 */

public class AssetSwapSpread extends ExchangedAsset{
	
	// CONSTRUCTOR
	/**
	 * Constructor using a pre-initalized {@link OrderBook}.
	 * @param assetName
	 * 		Name of the asset.
	 * @param orderBook
	 * 		{@link OrderBook} object to use as initial state.
	 */
	public AssetSwapSpread(String assetName, OrderBook orderBook) {
		super(assetName, orderBook);
	}
	
	/**
	 * Constructor randomly initializing the embedded {@link OrderBook} object, given a midPrice
	 * and a tickSize.
	 * @param assetName
	 * 		Name of the asset.
	 * @param midPrice
	 * 		Initial mid price.
	 * @param tickSize
	 * 		Increment between two possible orders.
	 */
	public AssetSwapSpread(String assetName, double midPrice, double tickSize) {
		super(assetName, midPrice, tickSize);
	}

}
