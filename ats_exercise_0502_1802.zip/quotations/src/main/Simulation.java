package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

/**
 * Entry point of the program.
 * @author alexis
 *
 */

public class Simulation {
	
	/**
	 * We initialize a {@link ZCBond}, a {@link AssetSwapSpread}, and build a synthetic {@link Swap}.
	 * Then we initialize a {@link ClientRequestSimulator}.
	 * A first thread runs the swap simulations. Two "sub-threads" are actually run in parallel,
	 * one for the {@link ZCBond}, one for the {@link AssetSwapSpread}.
	 * A second thread runs client requests simulations.
	 * We print the order books and the answer to the clients in the console.
	 * @param args
	 * 		N.A.
	 */
	public static void main(String[] args) {
		
		// Redirecting the output to a Log file.
		
		File file = new File("./OrderBookSimulation.log");
		PrintStream stream;
		try {
			stream = new PrintStream(file);
			System.setOut(stream);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, 102, 0.01);
		AssetSwapSpread bondSpread = new AssetSwapSpread("EUSS10", 33.84, 0.005);
		Swap swap = new Swap("EUSA10", bond, bondSpread, "2021-05-01");
		ClientRequestSimulator requests = new ClientRequestSimulator(swap);
		
		Thread thread1 = new Thread() {
		    public void run() {
		    	swap.run();
		    }
		};

		Thread thread2 = new Thread() {
		    public void run() {
		    	requests.run();
		    }
		};

		// Start the threads.
		thread1.start();
		thread2.start();

		// Wait for them both to finish
		try {
			thread1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		try {
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
