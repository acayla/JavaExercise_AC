package main;

import java.util.Vector;

/**
 * Abstract parent class for all the instruments embedding an {@link OrderBook}.
 * @author alexis
 *
 */

abstract public class ExchangedAsset extends Asset {
	
	// ATTRIBUTES
	protected OrderBook orderBook;
	
	
	// CONSTRUCTOR
	/**
	 * Builds an {@link ExchangedAsset} object from a pre-defined {@link OrderBook}.
	 * @param assetName
	 * 		Name of the asset.
	 * @param orderBook
	 * 		Pre-defined {@link OrderBook} object.
	 */
	public ExchangedAsset(String assetName, OrderBook orderBook) {
		super(assetName);
		this.orderBook = orderBook;
	}
	
	
	/**
	 * Builds an {@link ExchangedAsset} object and generates a random initial {@link OrderBook}.
	 * @param assetName
	 * 		Name of the asset.
	 * @param midPrice
	 * 		Mid price of asset.
	 * @param tickSize
	 * 		Tick size of the order book.
	 */
	public ExchangedAsset(String assetName, double midPrice, double tickSize) {
		super(assetName);
		this.orderBook = new OrderBook(0.995*midPrice, 1.005*midPrice, tickSize, 1000, assetName);
	}
	
	
	// GET
	/**
	 * @return Embedded {@link OrderBook} object.
	 */
	public OrderBook getOrderBook(){return orderBook;}
		
		
	// MAIN METHODS
	/**
	 * Runs the {@link ExchangedAsset} by simulating the embedded {@link OrderBook}.
	 */
	public void run() {
		this.orderBook.run();
	}
	
	
	/**
	 * Analyzes the order book to return the average price one would have executing a Bid {@link MarketOrder}
	 * for a given notional.
	 * @param quantity
	 * 		Notional of the price request.
	 */
	public double getBidPrice(int quantity) {
		Vector<LimitOrder> vecAskOrder = orderBook.getAskOrders();
		int idx = vecAskOrder.size() - 1;
		int executedQuantity = 0;
		int locallyExecutedQuantity;
		int orderSize;
		double orderQuote;
		double sumPrice = 0;
		while (executedQuantity < quantity && idx >= 0) {
			orderSize = vecAskOrder.elementAt(idx).getOrderSize();
			orderQuote = vecAskOrder.elementAt(idx).getQuote();
			locallyExecutedQuantity = Math.min(quantity - executedQuantity, orderSize);
			executedQuantity += locallyExecutedQuantity;
			sumPrice += locallyExecutedQuantity * orderQuote;
			idx--;
		}
		if (executedQuantity < quantity) {
			System.out.println("Warning: this order would execute the whole Ask part of the order book.");
		}
		return sumPrice / executedQuantity;
	};
	
	
	/**
	 * Analyzes the order book to return the average price one would have executing an Ask {@link MarketOrder}
	 * for a given notional.
	 * @param quantity
	 * 		Notional of the price request.
	 */
	public double getAskPrice(int quantity) {
		Vector<LimitOrder> vecBidOrder = orderBook.getBidOrders();
		int idx = 0;
		int executedQuantity = 0;
		int locallyExecutedQuantity;
		int orderSize;
		double orderQuote;
		double sumPrice = 0;
		while (executedQuantity < quantity && idx < vecBidOrder.size()) {
			orderSize = vecBidOrder.elementAt(idx).getOrderSize();
			orderQuote = vecBidOrder.elementAt(idx).getQuote();
			locallyExecutedQuantity = Math.min(quantity - executedQuantity, orderSize);
			executedQuantity += locallyExecutedQuantity;
			sumPrice += locallyExecutedQuantity * orderQuote;
			idx++;
		}
		if (executedQuantity < quantity) {
			System.out.println("Warning: this order would execute the whole Bid part of the order book.");
		}
		return sumPrice / executedQuantity;
	};
	
}
