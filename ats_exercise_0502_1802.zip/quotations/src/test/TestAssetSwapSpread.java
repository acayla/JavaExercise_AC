package test;

import java.util.Vector;

import org.junit.Test;

import main.AssetSwapSpread;
import main.LimitOrder;
import main.OrderBook;

public class TestAssetSwapSpread {
	
	@Test
	public void buildAssetSwapSpreadFromOrderBook() {
		double tickSize = 0.01;
		LimitOrder l1 = new LimitOrder("Bid", 1000, 33.83);
		LimitOrder l2 = new LimitOrder("Ask", 1000, 33.85);
		Vector<LimitOrder> vecLimitOrders = new Vector<LimitOrder>();
		vecLimitOrders.add(l1);
		vecLimitOrders.add(l2);
		OrderBook orderBook = new OrderBook(vecLimitOrders, tickSize);
		AssetSwapSpread spead = new AssetSwapSpread("EUSS10", orderBook);
		spead.getOrderBook().print();
	}
	
	@Test
	public void buildAssetSwapSpreadRandomInit() {
		double tickSize = 0.02;
		double midPrice = 33.84;
		AssetSwapSpread spead = new AssetSwapSpread("EUSS10", midPrice, tickSize);
		spead.getOrderBook().print();
	}

}
