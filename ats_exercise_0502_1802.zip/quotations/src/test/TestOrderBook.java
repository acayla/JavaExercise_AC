package test;

import java.util.Vector;
import org.junit.Test;

import main.CancelOrder;
import main.LimitOrder;
import main.MarketOrder;
import main.OrderBook;

public class TestOrderBook {
	
	@Test
	public void orderBookBasicBehaviour() {
		
		LimitOrder l1 = new LimitOrder("Ask", 1000, 100.2);
		LimitOrder l2 = new LimitOrder("Bid", 1000, 99.8);
		Vector<LimitOrder> vecLimitOrders = new Vector<LimitOrder>();
		vecLimitOrders.add(l1);
		vecLimitOrders.add(l2);
		OrderBook orderBook = new OrderBook(vecLimitOrders, 0.1);
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.8) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.8) < 1e-6;
		
		
		// TRY TO INCREMENT EXISTING ORDERS
		try {
			orderBook.insertOrder(l1);
			orderBook.insertOrder(l2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.8) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.8) < 1e-6;
		
		
		// TRY TO INSERT EXTREME ORDERS
		try {
			LimitOrder l3 = new LimitOrder("Ask", 1000, 100.3);
			LimitOrder l4 = new LimitOrder("Bid", 1000, 99.7);
			orderBook.insertOrder(l3);
			orderBook.insertOrder(l4);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.3) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.8) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.7) < 1e-6;
		
		// TRY TO INSERT CLOSE-TO-MID ORDERS
		try {
			LimitOrder l5 = new LimitOrder("Ask", 1000, 100.1);
			LimitOrder l6 = new LimitOrder("Bid", 1000, 99.9);
			orderBook.insertOrder(l5);
			orderBook.insertOrder(l6);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.3) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.1) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.9) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.7) < 1e-6;
		
		// TRY TO EXECUTE MARKET ORDERS
		try {
			MarketOrder m1 = new MarketOrder("Ask", 500);
			orderBook.insertOrder(m1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.3) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.1) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.9) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.7) < 1e-6;
		
		try {
			MarketOrder m2 = new MarketOrder("Bid", 1500);
			orderBook.insertOrder(m2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.05) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.3) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.9) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.7) < 1e-6;
		
		// TRY TO EXECUTE CANCEL ORDER
		try {
			CancelOrder c1 = new CancelOrder("Bid", 500, 99.9);
			orderBook.insertOrder(c1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		orderBook.print();
		assert Math.abs(orderBook.getMidPrice() - 100.0) < 1e-6;
		assert Math.abs(orderBook.getMaxAsk() - 100.3) < 1e-6;
		assert Math.abs(orderBook.getMinAsk() - 100.2) < 1e-6;
		assert Math.abs(orderBook.getMaxBid() - 99.8) < 1e-6;
		assert Math.abs(orderBook.getMinBid() - 99.7) < 1e-6;
		
	}
	
	
	@Test
	public void runOrderBook() {
		OrderBook orderBook = new OrderBook(101.0, 103.0, 0.05, 1000, "DEMO");
		orderBook.run();
	}
	

}
