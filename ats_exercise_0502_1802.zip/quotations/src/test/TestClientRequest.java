package test;

import org.junit.Test;

import main.Asset;
import main.ClientRequest;
import main.ZCBond;

public class TestClientRequest {
	
	@Test
	public void TestClientRequestFull() {
		Asset asset = new ZCBond("DUMMY", "2021-11-02", 100, 102.004, 0.1);
		ClientRequest clientRequest = new ClientRequest(asset, "Bid", 2000);
		clientRequest.answerClient();
	}

}
