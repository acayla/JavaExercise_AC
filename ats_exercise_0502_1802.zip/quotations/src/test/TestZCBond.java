package test;

import java.util.Vector;

import org.junit.Test;

import main.LimitOrder;
import main.OrderBook;
import main.ZCBond;

public class TestZCBond {
	
	@Test
	public void buildZCBondFromOrderBook() {
		double tickSize = 0.05;
		LimitOrder l1 = new LimitOrder("Bid", 1000, 102.25);
		LimitOrder l2 = new LimitOrder("Ask", 1000, 102.15);
		Vector<LimitOrder> vecLimitOrders = new Vector<LimitOrder>();
		vecLimitOrders.add(l1);
		vecLimitOrders.add(l2);
		OrderBook orderBook = new OrderBook(vecLimitOrders, tickSize);
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, orderBook);
		bond.getOrderBook().print();
	}
	
	@Test
	public void buildZCBondRandomInit() {
		double tickSize = 0.05;
		double midPrice = 103.0;
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, midPrice, tickSize);
		bond.getOrderBook().print();
	}
	
	@Test
	public void timeToMaturity() {
		double tickSize = 0.05;
		double midPrice = 102.004;
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, midPrice, tickSize);
		assert Math.abs(bond.getTimeToMaturity("2021-05-02") - 9.797260) < 1e-6;
	}
	
	@Test
	public void yieldToMaturity() {
		double tickSize = 0.05;
		double midPrice = 102.004;
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, midPrice, tickSize);
		assert Math.abs(bond.getYieldToMaturity("2021-05-02", midPrice) - -0.00202524) < 1e-8;
	}

}
