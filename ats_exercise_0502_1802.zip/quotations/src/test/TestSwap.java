package test;

import org.junit.Test;

import main.AssetSwapSpread;
import main.Swap;
import main.ZCBond;

public class TestSwap {
	
	@Test
	public void testRunSwap() {
		ZCBond bond = new ZCBond("CTEUR10Y", "2031-02-15", 100, 102, 0.02);
		AssetSwapSpread bondSpread = new AssetSwapSpread("EUSS10", 33.84, 0.02);
		Swap swap = new Swap("EUSA10", bond, bondSpread, "2021-05-01");
		swap.run();
	}

}
