package test;

import org.junit.Test;

import main.ClientRequestSimulator;
import main.ZCBond;

public class TestClientRequestSimulator {
	
	@Test
	/**
	 * A bond is fixed (i.e. order book randomly initialized), and we simulate client requests.
	 */
	public void testRun() {
		ZCBond bond = new ZCBond("DUMMY", "2056-07-28", 100, 105.5, 0.02);
		ClientRequestSimulator clientRequestSimulator = new ClientRequestSimulator(bond);
		clientRequestSimulator.run();
	}

}
